#include <iostream>

bool IsPrime(int num) {
    // Loop through all number from 2 until the selected number
    for(int index = 2; index <= num - 1; index++) {
        // If the number is divisible by index, then it is not prime
        if(num % index == 0) return false;
    }

    return true;
}

int main()
{
    // Set data for application
    int number_of_primes = 0;

    // Interact with user to fill missing data
    std::cout << "Enter number of primes to show: ";
    std::cin >> number_of_primes;

    for(int num = 1; num <= number_of_primes; num++)
    {
        // Show user the result
        if(IsPrime(num)) std::cout << num << ", ";
    }

}
